import { createRouter, createWebHashHistory } from "vue-router";
// لاحظ هنا استبدلنا @ بالمسار المباشر لكي يفهمه GitHub Pages فوراً
import HomeView from "../views/HomeView.vue";
import MovieView from "../views/MovieView.vue";

const router = createRouter({
  // استخدمنا createWebHashHistory لضمان عمل الروابط في المواقع المجانية
  history: createWebHashHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      name: "home",
      component: HomeView,
    },
    {
      path: "/movie",
      name: "movie",
      component: MovieView,
    },
  ],
});

export default router;
