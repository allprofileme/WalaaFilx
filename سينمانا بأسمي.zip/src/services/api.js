import axios from "axios";

// وضعنا المفتاح مباشرة هنا لضمان عمل الأفلام على كل الشبكات (آسيا، زين، كرك)
// هذا يحل مشكلة عدم قراءة ملف الـ .env في المواقع المجانية
const apiKey = "851ccad574593617d921dde51303751c";

const api = axios.create({
  baseURL: "https://api.themoviedb.org/3",
  params: {
    api_key: apiKey,
    language: "ar-SA", // أضفت لك هذا السطر لكي تظهر أسماء الأفلام والوصف بالعربي!
  },
});

export default api;
