async function initApp() {
    const grid = document.getElementById('movie-grid');
    const loader = document.getElementById('loader');

    const movies = await getTrendingMovies();
    if (loader) loader.style.display = 'none';

    if (movies.length > 0) {
        grid.innerHTML = "";
        movies.forEach(movie => {
            const card = document.createElement('div');
            card.className = 'movie-card';
            card.onclick = () => openPlayer(movie.id);
            card.innerHTML = `
                <img src="${CONFIG.IMG_URL + movie.poster_path}" alt="${movie.title}">
                <div class="movie-info">
                    <h3>${movie.title}</h3>
                </div>
            `;
            grid.appendChild(card);
        });
    } else {
        grid.innerHTML = "<p style='text-align:center'>خطأ في الاتصال بسيرفر الأفلام.</p>";
    }
}

window.onload = initApp;
