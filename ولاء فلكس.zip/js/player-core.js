let activeMovieId = "";

function toggleFamilyMode() {
    isFamilyMode = !isFamilyMode;
    const btn = document.getElementById('family-toggle');
    btn.innerHTML = isFamilyMode ? "الوضع العائلي: مفعّل ✅" : "الوضع العائلي: معطّل ❌";
    btn.classList.toggle('active', isFamilyMode);
    
    // إذا كان المشغل مفتوحاً، نقوم بتحديث السيرفر فوراً
    if (document.getElementById('player-overlay')) renderPlayer();
}

function openPlayer(movieId) {
    activeMovieId = movieId;
    renderPlayer();
}

function renderPlayer() {
    // إزالة أي مشغل قديم
    const existing = document.getElementById('player-overlay');
    if (existing) existing.remove();

    // اختيار السيرفر بناءً على الوضع العائلي
    const serverBase = isFamilyMode ? CONFIG.SERVERS.CLEAN : CONFIG.SERVERS.NORMAL;
    const finalUrl = serverBase + activeMovieId;

    const overlay = `
        <div id="player-overlay" class="overlay">
            <div class="player-container">
                <div class="player-header">
                    <span>Arabs Star // نظام البث الآمن //</span>
                    <button class="close-btn" onclick="closePlayer()">إغلاق X</button>
                </div>
                
                <iframe src="${finalUrl}" frameborder="0" allowfullscreen 
                    sandbox="allow-forms allow-scripts allow-same-origin allow-presentation">
                </iframe>

                <div class="player-footer">
                    <p>⚙️ يمكنك تغيير الدقة واللغة من داخل أيقونة الإعدادات في الفيديو.</p>
                </div>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', overlay);
}

function closePlayer() {
    const player = document.getElementById('player-overlay');
    if (player) player.remove();
}
