// Arabs Star Configuration V2.6
const CONFIG = {
    API_KEY: '851ccad574593617d921dde51303751c',
    BASE_URL: 'https://api.themoviedb.org/3',
    IMG_URL: 'https://image.tmdb.org/t/p/w500',
    
    // سيرفرات تدعم الترجمة والدقة (بدون إعلانات)
    SERVERS: {
        NORMAL: "https://vidsrc.pro/embed/movie/", // السيرفر الكامل (تغيير لغة ودقة)
        CLEAN: "https://vidsrc.to/embed/movie/"   // سيرفر بديل للوضع العائلي (أكثر استقراراً)
    }
};

let isFamilyMode = true; // تفعيل الوضع العائلي افتراضياً
