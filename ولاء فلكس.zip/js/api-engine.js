async function getTrendingMovies() {
    try {
        const response = await fetch(`${CONFIG.BASE_URL}/trending/movie/day?api_key=${CONFIG.API_KEY}&language=ar-SA`);
        if (!response.ok) throw new Error("Connection Error");
        const data = await response.json();
        return data.results;
    } catch (error) {
        console.error("API Error:", error);
        return [];
    }
}
